"""AegisBrain backend test suite."""
